//Game variables
let mysteryNumber = Math.floor(Math.random() * 100);
let playersGuess = 0;
let guessesRemaining = 10;
let guessesMade = 0;
let gameState = "";
let gameWon = false;

//The input and output fields
let input = document.querySelector("#input");
let output = document.querySelector("#output");

//The button
let button = document.querySelector("button");
button.addEventListener("click", clickHandler, false);
button.style.cursor = "pointer";

//Listen for enter key presses
window.addEventListener("keydown", keydownHandler, false);

function keydownHandler(event)
{
  if(event.keyCode === 13)
  {
    validateInput();
  }
}

function clickHandler()
{
  validateInput();
}

function validateInput()
{
  playersGuess = parseInt(input.value);
  
  //If you're worried about infinity, use this:
  //!isNaN(playersGuess) && isFinite(playersGuess);
  if(isNaN(playersGuess))
  {
    output.innerHTML = "Please enter a number.";
  }
  else
  {
    playGame();
  }
}

function playGame()
{
  guessesRemaining = guessesRemaining - 1;
  guessesMade = guessesMade + 1;
  gameState 
    = " Guess: " + guessesMade 
    + ", Remaining: " + guessesRemaining;
  
  playersGuess = parseInt(input.value);

  if(playersGuess > mysteryNumber)
  {
    output.innerHTML = "That's too high." + gameState;
    
    //Check for the end of the game
    if (guessesRemaining < 1)
    {
      endGame();
    }
  }
  else if(playersGuess < mysteryNumber)
  {
    output.innerHTML = "That's too low." + gameState;
    
    //Check for the end of the game
    if (guessesRemaining < 1)
    {
      endGame();
    }
  }
  else if(playersGuess === mysteryNumber)
  {
    gameWon = true;
    endGame();
  }
}


function endGame()
{
  if (gameWon)
  {
    output.innerHTML
      = "Yes, it's " + mysteryNumber + "!" + "<br>" 
      + "It only took you " + guessesMade + " guesses.";
  }
  else
  {
    output.innerHTML
      = "No more guesses left!" + "<br>" 
      + "The number was: " + mysteryNumber + ".";
  }
  
  //Disable the button
  button.removeEventListener("click", clickHandler, false);
  button.disabled = true;
  
  //Disable the enter key
  window.removeEventListener("keydown", keydownHandler, false);
  
  //Disable the input field
  input.disabled = true;
}