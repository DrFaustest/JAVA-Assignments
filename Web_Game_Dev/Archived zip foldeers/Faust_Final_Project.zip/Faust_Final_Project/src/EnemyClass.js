export class Enemy {
    constructor(gameCanvas, scaleFactor, type = Math.random() < 0.7 ? 1 : 2) {
      this.gameCanvas = gameCanvas;
      this.scaleFactor = scaleFactor;
      this.enemyImage = new Image();
      this.enemyImage.src = "../images/enemyShip.png";
      this.enemyType2Image = new Image();
      this.enemyType2Image.src = "../images/enemyUFO.png";
      this.size = 40 * this.scaleFactor;
      this.x = Math.random() * (gameCanvas.width - this.size * 2) + this.size;
      this.y = 0;
      this.width = this.size;
      this.height = this.size;
      this.type = type; 
      this.hitPoints = this.type === 1 ? 1 : 2; 
      this.image = this.type === 1 ? this.enemyImage : this.enemyType2Image; 
    }
  
    draw(gameContext) {
      gameContext.drawImage(this.image, this.x, this.y, this.width, this.height);
    }
  
    move() {
      this.y += 0.5 * this.scaleFactor;
      if (this.y + this.size > this.gameCanvas.height) {
        // when the enemy reaches the bottom of the screen it should be removed and lives should decrease
        // this logic should be handled in the game loop because it requires access to the list of enemies and the lives count
        return true;
      }
      return false;
    }
  
    static spawn(gameCanvas, scaleFactor) {
        return new Enemy(gameCanvas, scaleFactor);
    }
  }
  