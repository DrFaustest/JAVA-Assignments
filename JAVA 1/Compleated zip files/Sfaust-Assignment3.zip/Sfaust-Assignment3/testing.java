public class testing {
    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println("\u001B[30mThis text is black!\u001B[30m");
        System.out.println("\u001B[31mThis text is red!\u001B[31m");
        System.out.println("\u001B[32mThis text is green!\u001B[32m");
        System.out.println("\u001B[33mThis text is yellow!\u001B[33m");
        System.out.println("\u001B[34mThis text is blue!\u001B[34m");
        System.out.println("\u001B[35mThis text is magenta!\u001B[35m");
        System.out.println("\u001B[36mThis text is cyan!\u001B[36m");
        System.out.println("\u001B[37mThis text is white!\u001B[37m");
        System.out.println("\u001B[38mThis text is default!\u001B[39m");
        System.out.println("Hello World");
    }
    
}

/*  \u001B[30m - black
    \u001B[31m - red
    \u001B[32m - green
    \u001B[33m - yellow
    \u001B[34m - blue
    \u001B[35m - magenta
    \u001B[36m - cyan
    \u001B[37m - white
    \u001B[39m - default
*/